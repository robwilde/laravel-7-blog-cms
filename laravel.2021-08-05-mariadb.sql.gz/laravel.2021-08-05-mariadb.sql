-- MySQL dump 10.18  Distrib 10.3.27-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: laravel
-- ------------------------------------------------------
-- Server version	10.3.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `thumbnail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_published` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`),
  UNIQUE KEY `categories_slug_unique` (`slug`),
  KEY `categories_user_id_foreign` (`user_id`),
  CONSTRAINT `categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,1,'https://s.w.org/style/images/about/WordPress-logotype-standard-white.png','WordPress','wordpress','1','2021-08-03 10:50:04','2021-08-03 10:50:04'),(2,1,'https://mrwilde-dev.lndo.site/storage/galleries/life_1628032639.jpg','Life','life','1','2021-08-03 23:17:32','2021-08-03 23:17:32'),(3,1,'https://mrwilde-dev.lndo.site/storage/galleries/nasa-Q1p7bh3SHj8-unsplash_1628082332.jpg','Future','future','1','2021-08-04 13:05:51','2021-08-04 13:05:51'),(4,1,'https://mrwilde-dev.lndo.site/storage/galleries/php-4wxWBy8Jo1I-unsplash_1628082402.jpg','PHP','php','1','2021-08-04 13:06:53','2021-08-04 13:06:53'),(5,1,'https://mrwilde-dev.lndo.site/storage/galleries/tech-news-SYTO3xs06fU-unsplash_1628166049.jpg','Tech News','tech-news','1','2021-08-05 12:21:04','2021-08-05 12:21:04');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_posts`
--

DROP TABLE IF EXISTS `category_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_posts_category_id_foreign` (`category_id`),
  KEY `category_posts_post_id_foreign` (`post_id`),
  CONSTRAINT `category_posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_posts_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_posts`
--

LOCK TABLES `category_posts` WRITE;
/*!40000 ALTER TABLE `category_posts` DISABLE KEYS */;
INSERT INTO `category_posts` VALUES (1,3,4,NULL,NULL),(2,1,5,NULL,NULL),(3,5,6,NULL,NULL);
/*!40000 ALTER TABLE `category_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries`
--

DROP TABLE IF EXISTS `galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `image_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `galleries_user_id_foreign` (`user_id`),
  CONSTRAINT `galleries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries`
--

LOCK TABLES `galleries` WRITE;
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
INSERT INTO `galleries` VALUES (4,1,'desktop-hd_1627997220.jpg','2021-08-03 13:27:00','2021-08-03 13:27:00'),(5,1,'clean-code_1627997251.jpg','2021-08-03 13:27:31','2021-08-03 13:27:31'),(6,1,'git-rebase-merge_1627997328.jpeg','2021-08-03 13:28:48','2021-08-03 13:28:48'),(7,1,'dev-team-3_1627997446.png','2021-08-03 13:30:46','2021-08-03 13:30:46'),(8,1,'life_1628032639.jpg','2021-08-03 23:17:19','2021-08-03 23:17:19'),(9,1,'Lwrvslftr2_1628081877.png','2021-08-04 12:57:57','2021-08-04 12:57:57'),(10,1,'nasa-Q1p7bh3SHj8-unsplash_1628082332.jpg','2021-08-04 13:05:32','2021-08-04 13:05:32'),(11,1,'php-4wxWBy8Jo1I-unsplash_1628082402.jpg','2021-08-04 13:06:42','2021-08-04 13:06:42'),(12,1,'eneergy-7e2pe9wjL9M-unsplash_1628082513.jpg','2021-08-04 13:08:33','2021-08-04 13:08:33'),(13,1,'WordCamp-Sunshine-Coast-Wrapup-1_1628084297.jpg','2021-08-04 13:38:17','2021-08-04 13:38:17'),(14,1,'Wordcamp_Sunshine_Coast_Hero_Background_7_1628084879.jpg','2021-08-04 13:47:59','2021-08-04 13:47:59'),(15,1,'mindstone-image_1628165821.svg','2021-08-05 12:17:01','2021-08-05 12:17:01'),(16,1,'tech-news-SYTO3xs06fU-unsplash_1628166049.jpg','2021-08-05 12:20:49','2021-08-05 12:20:49');
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2020_05_13_111343_create_categories_table',1),(5,'2020_05_13_111359_create_posts_table',1),(6,'2020_05_13_111413_create_galleries_table',1),(7,'2020_05_13_111436_create_category_posts_table',1),(8,'2021_08_04_122221_update-posts-table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `thumbnail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_published` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_title_unique` (`title`),
  UNIQUE KEY `posts_slug_unique` (`slug`),
  KEY `posts_user_id_foreign` (`user_id`),
  CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (2,1,'https://mrwilde-dev.lndo.site/storage/galleries/desktop-hd_1627997220.jpg','About','about','so here is a little something about me','<p>Who is Mr Wilde?</p>\n\n<p>I am just am guy, getting on in life, who just loves building things.</p>\n\n<p>I have worked in and around tech for more than 30 years now, from electronic engineer to technical director of a night club. I was self employed for more than a decade starting with systems administration of Windows servers and finished up building website with WordPress.</p>\n\n<p>As I draw near the big 50, I am still wanting to learn more and grow. I have worked with PHP for the last 5 years and now learning Java. I can&#39;t stop learning, it keeps me feeling young and gets me out of bed everyday.</p>\n\n<p>When I am not writting code I love to build PC&#39;s, go for rides on one of my Motorcylces or I will be watching another video on Liquid Flouride Thorium Reactors.</p>\n\n<p><a href=\"https://app.daily.dev/mrwilde\"><img alt=\"Robert Wilde\'s Dev Card\" src=\"https://api.daily.dev/devcards/dfc2dd9288db42b192c2a6e2d96084ac.png?r=kl2\" style=\"height:278px; width:204px\" /></a></p>','page','1','2021-08-03 11:03:52','2021-08-04 12:17:35',NULL),(4,1,'https://mrwilde-dev.lndo.site/storage/galleries/eneergy-7e2pe9wjL9M-unsplash_1628082513.jpg','Thorium is the new GOLD','thorium-is-the-new-gold','The answer to cheap and clean power, is Thorium and Australia has one of the largest supplies of it on the planet','<p><a href=\"https://youtu.be/jjM9E6d42-M\" target=\"_blank\"><em><strong>Why Thorium rocks -- Science Sundays</strong></em></a></p>\r\n\r\n<p>My Favourite videos on Youtube now are everything from&nbsp;@kirksorensen, by @gordonmcdowell, talking about Thorium and Liquid Fluoride Thorium Reactor.</p>\r\n\r\n<p><a href=\"https://youtu.be/YVSmf_qmkbg\" target=\"_blank\"><strong><em>Kirk Sorensen @ PROTOSPACE on Liquid Fluoride Thorium Reactors</em></strong></a></p>\r\n\r\n<p>Right at the start Kirk outlines an estimated $1000,000,000 return from 1 Tonne of Thorium and this doc I found from 2007,&nbsp;<a href=\"http://url.mrwilde.com/25A2vK5\">http://url.mrwilde.com/25A2vK5</a>, outlines not only is Australia the largest deposit of Thorium on the planet, but we also have 452,000 Tonnes. So you don&#39;t hurt yourself, as it was hurting my head getting around that number, let me show what that is in dollars. $452 000, 000, 000, 000 or $452 TRILLION. Depending on what format you use to identify&nbsp;billion and trillion but you get the point. Even you dumped a billion into an investment or 5 billion, how could you not get a return.</p>\r\n\r\n<p>I am no financial guru or anything like that but seriously what am I missing? How is this not the next big boom for this country? Imagine a publicly owned company producing clean power from an abundant source, mined locally that could also produce FUEL. There is a process, that has been tested and proven, that can create aviation fuel that is more efficient and cleaner than oil based petroleum. &nbsp;So basically&nbsp;Petrol from Sea Water and better and cleaner than from oil PLUS it will remove Co2 from the atmosphere. Watch&nbsp;below; it will blow your mind.</p>\r\n\r\n<p><a href=\"https://youtu.be/0BybPPIMuQQ\" target=\"_blank\"><strong><em>&quot;NASA&quot; - THORIUM REMIX 2016</em></strong></a></p>\r\n\r\n<p>Thorium is the new GOLD and nearly every other precious metal all rolled into one, and it is everywhere. Not only generate power efficiently, with ZERO emission, but it has</p>\r\n\r\n<ul>\r\n	<li>a short-life waste ( around 300 years opposed to current 10, 000 years)</li>\r\n	<li>desalinate water</li>\r\n	<li>produce very rare fuel for deep space missions</li>\r\n	<li>create unique isotopes which help fight cancer</li>\r\n	<li>assist in the production aviation fuel from seawater</li>\r\n</ul>\r\n\r\n<p><a href=\"https://youtu.be/biToH42YZZ4\" target=\"_blank\"><strong><em>THORIUM 232 - From History to Reactor [2019]</em></strong></a></p>\r\n\r\n<p>OMG-WTF It&#39;s like aliens have landed, given us the answers to most of the major world problems and we just shrug and say cool, then go about the day. My drive in life now is to generate enough recurring revenue in business so I can spend more time learning about this technology and maybe even studying Nuclear Engineering. If you want something done, sometimes you have to do it yourself. I want my son living in a world powered by <a href=\"https://www.facebook.com/hashtag/lftr?source=feed_text&amp;story_id=10154546208450348\">‪#&lrm;LFTR‬</a> <a href=\"https://www.facebook.com/hashtag/thorium?source=feed_text&amp;story_id=10154546208450348\">‪#&lrm;Thorium‬</a></p>\r\n\r\n<p>Please comment, what do you think. If you disagree with anything here, tell me. We need to discuss this and talk about this as much as possible. It is not new technology it was discovered over 50 Years ago and forgotten. The more we talk about it, the more people&nbsp;know and the closer we are to the world running on #Thorium #LFTR</p>\r\n\r\n<p><a href=\"https://youtu.be/U1lIfFcxVuY\" target=\"_blank\"><strong><em>Thorium - The Future of Energy?</em></strong></a></p>','post','1','2021-08-04 13:17:27','2021-08-05 14:47:28','2016-06-03'),(5,1,'https://mrwilde-dev.lndo.site/storage/galleries/Wordcamp_Sunshine_Coast_Hero_Background_7_1628084879.jpg','This one time at WordCamp - I was the person Speaking','this-one-time-at-wordcamp-i-was-the-person-speaking','My First time not only attending WordCamp but also speaking.','<p>It is all done, finished, over and kaput. WordCampSC has come and gone and what a fantastic weekend. If I were only there as an attendee, I would still have learnt so much and been glad to have gone but I was speaking for the first time.</p>\r\n\r\n<p>Did it go as planned? HELL NO! Part of the live demo material did not play out as rehearsed, several hours a day leading up to the event, and every time I looked into the crowd all I could see were the faces of, what appeared to be, very confused people. So why am I so happy? It is never, ever as bad as you think.</p>\r\n\r\n<p>Once I had finally stumbled my way to the end and answered a few questions, which I was also terrified to do, I had a chance to talk to several of the people who attended. Everyone I spoke to got something out it, and that is the outcome you are seeking. If you can walk away confident that people can leave knowing a little more than when they entered, you achieved something great.</p>\r\n\r\n<p>The first thing I noticed after presenting is the massive appreciation and respect you now have towards others that do the same. You know the time, effort and anxiety that goes into creating a presentation you are happy with. Believe me, when I say everyone, no matter how successful or famous they are, gets the butterflies and a case of anxiety before standing at the podium.</p>\r\n\r\n<p>I am no stranger to speaking in front of large crowds or using a mic. I worked nightclubs for nearly ten years as Lighting Director, MC and DJ as well as hosting many large events. Everything changes when you are in front of people who have come to hear you talk, with the hope and desire to learn something new.</p>\r\n\r\n<p>I think most individuals who have thought about speaking but have not, as well as those that avoided it for years and then finally did it, would both have the same reasons behind not taking the plunge. Lack of self-confidence. That voice in your head when you are looking at the submission form saying things like:</p>\r\n\r\n<ul>\r\n	<li>&quot;Why would anyone want to hear me speak.&quot;</li>\r\n	<li>&quot;Other people in my industry or field are smarter than me.&quot;</li>\r\n	<li>&quot;I am not that good at what I do.&quot;</li>\r\n</ul>\r\n\r\n<p>That last one has always been my Achilles heel; I never believe I am any good at what I do until I get some gratification or genuine appreciation for it. Working alone at home, as well as living alone half the time, I am devoid of any professional appreciation for my job. Clients do compliment the work and tell you how much they like it but it is not the same as an appraisal from a colleague.</p>\r\n\r\n<p>Speaking at WordCamp has made me realise we all have something to share and if one person can leave your session knowing just a little more than when they sat down, you have succeeded in a massive way.<br />\r\nThere is no greater feeling of achievement than helping others, in any way. It truly is addictive and I have already submitted an idea for the next WordCamp in Sydney later this year. Also hoping to speak later this week at our local meetup in Brisbane.</p>\r\n\r\n<p>I have a mission this year to share as much as possible and be social. I read something last year that I thought was profound.</p>\r\n\r\n<blockquote>\r\n<p>&quot;The meaning of life is to find your gift, the purpose of life is to share it.&quot;</p>\r\n</blockquote>\r\n\r\n<p>If you have thought about speaking at an event, meetup or perhaps even doing a vlog, do not hold back. You have so much to give to others and to gain from the experience. Can not wait to do it again.</p>','post','1','2021-08-04 13:41:16','2021-08-05 14:47:37','2016-04-09'),(6,1,NULL,'Links of the Week','links-of-the-week','allways looking for something cool','<h3><strong><em><a href=\"https://www.mindstone.com/\" target=\"_blank\"><img alt=\"\" src=\"https://mrwilde-dev.lndo.site/storage/galleries/mindstone-image_1628165821.svg\" style=\"float:right; height:177px; width:206px\" /></a>Apps</em></strong></h3>\r\n\r\n<p>First thing this week the I am really liking is <a href=\"https://www.mindstone.com/\" target=\"_blank\">https://www.mindstone.com/</a> If your like me and like to scour the internet but don&#39;t know where to put it all, this is an online app for you. It will install in your browser and allow to capture pages, notes, RSS feeds into your workspaces with reminders coming at you daily to review what you captured. You can highlight content into colored categories then access the info in a comments section.</p>\r\n\r\n<p>I am still learning some of the key features but I have been contacted by the CEO who wants to tee up some time to talk about the app and how I am using it. I think it is going to be a great tool for curating info online.</p>\r\n\r\n<h3><em><strong>Packages</strong></em></h3>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3><em><strong>Articles</strong></em></h3>\r\n\r\n<p>This is an old one but I was watching a video from a great course by <a href=\"https://paulredmond.gumroad.com/?_ga=2.192349358.508848572.1628156016-732088172.1628156016\" target=\"_blank\">Paul Redmond</a> called &nbsp;Docker for PHP Developers. The last section of the course goes over deployment and CI/CD with GitLab which is great being I have my own GitLab server at home (who doesn&#39;t).</p>\r\n\r\n<p>He details something I have been wanting to play with for sometime during my last role at Infoxchange, Docker multi-stage builds. The Dockerfile used for the main app was reasonable in size but on every build and deployment the same processes would be repeated, install PHP, install Composer, install Node and I was looking for a way for these steps to be isolated to there own process and Docker multi-stage builds is the answer.<br />\r\nCheck out the article on <a href=\"https://laravel-news.com/multi-stage-docker-builds-for-laravel\" target=\"_blank\"><em>Laravel News</em></a>.</p>','post','1','2021-08-05 12:29:03','2021-08-05 14:47:45','2021-08-05');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Robert Wilde','robert@mrwilde.com',NULL,'$2y$10$QCdDDKq7J7mPtEhO5m815.r6wIvKZEPkdvewPgFwuOGnBhAuDiB4e','','2021-08-03 10:46:03','2021-08-03 10:46:03');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-05 14:49:37
